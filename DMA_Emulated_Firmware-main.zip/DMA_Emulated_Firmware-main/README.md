This is a public firmware, so don’t expect it to last long (EAC/BE/Rivals/COD will work fine for a couple of months, for sure) This is not my project, I'm just sharing, so please don't add me and ask me for things!

#### Firmware - EAC/BE bypass
#### Firmware v2 - VGK/ACE/EAC/BE bypass
